package com.mycompany.CRUDDataPenjualan;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.sql.*;
import java.math.BigDecimal;

public class CRUDDataPenjualan extends JFrame {
    private Connection conn;
    private DefaultTableModel tableModel;
    private JTable table;
    private JTextField txtIdPelanggan, txtIdMobil, txtTotalBiaya;
    private JButton btnCreate, btnUpdate, btnDelete, btnRefresh;

    public CRUDDataPenjualan() {
        initUI();
        connectToDatabase();
        refreshTable();
    }

    // 1. Inisialisasi UI
    private void initUI() {
        setTitle("CRUD Data Penjualan");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLayout(null);

        JLabel lblIdPelanggan = new JLabel("ID Pelanggan:");
        JLabel lblIdMobil = new JLabel("ID Mobil:");
        JLabel lblTotalBiaya = new JLabel("Total Biaya:");

        txtIdPelanggan = new JTextField();
        txtIdMobil = new JTextField();
        txtTotalBiaya = new JTextField();

        lblIdPelanggan.setBounds(20, 60, 100, 25);
        lblIdMobil.setBounds(20, 100, 100, 25);
        lblTotalBiaya.setBounds(20, 140, 100, 25);

        txtIdPelanggan.setBounds(130, 60, 200, 25);
        txtIdMobil.setBounds(130, 100, 200, 25);
        txtTotalBiaya.setBounds(130, 140, 200, 25);

        btnCreate = new JButton("Create");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnRefresh = new JButton("Refresh");

        btnCreate.setBounds(350, 60, 100, 25);
        btnUpdate.setBounds(350, 100, 100, 25);
        btnDelete.setBounds(350, 140, 100, 25);
        btnRefresh.setBounds(350, 180, 100, 25);

        // Tabel untuk menampilkan data penjualan
        tableModel = new DefaultTableModel(new String[]{"ID Penjualan", "ID Pelanggan", "ID Mobil", "Total Biaya"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 220, 750, 300);

        // Tambahkan komponen ke frame
        add(lblIdPelanggan);
        add(lblIdMobil);
        add(lblTotalBiaya);
        add(txtIdPelanggan);
        add(txtIdMobil);
        add(txtTotalBiaya);
        add(btnCreate);
        add(btnUpdate);
        add(btnDelete);
        add(btnRefresh);
        add(scrollPane);

        // Event Listener
        btnCreate.addActionListener(e -> createData());
        btnUpdate.addActionListener(e -> updateData());
        btnDelete.addActionListener(e -> deleteData());
        btnRefresh.addActionListener(e -> refreshTable());

        // Calculate total biaya when ID Mobil is changed
        txtIdMobil.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                calculateTotalBiaya();
            }
        });

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int selectedRow = table.getSelectedRow();
                txtIdPelanggan.setText(tableModel.getValueAt(selectedRow, 1).toString());
                txtIdMobil.setText(tableModel.getValueAt(selectedRow, 2).toString());
                txtTotalBiaya.setText(tableModel.getValueAt(selectedRow, 3).toString());
            }
        });
    }

    // 2. Koneksi ke Database
    private void connectToDatabase() {
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/showroom", "root", "");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database connection failed: " + ex.getMessage());
        }
    }

    // 3. Fungsi Create
    private void createData() {
        String idPelanggan = txtIdPelanggan.getText();
        String idMobil = txtIdMobil.getText();
        String totalBiaya = txtTotalBiaya.getText();

        try {
            String sql = "INSERT INTO data_penjualan (idpelanggan, idmobil, totalbiaya) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, idPelanggan);
            stmt.setString(2, idMobil);
            stmt.setString(3, totalBiaya);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan!");
            refreshTable();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal menambahkan data: " + ex.getMessage());
        }
    }

    // 4. Fungsi Update
    private void updateData() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            String idPenjualan = table.getValueAt(selectedRow, 0).toString();
            String idPelanggan = txtIdPelanggan.getText();
            String idMobil = txtIdMobil.getText();
            String totalBiaya = txtTotalBiaya.getText();

            try {
                String sql = "UPDATE data_penjualan SET idpelanggan = ?, idmobil = ?, totalbiaya = ? WHERE idpenjualan = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, idPelanggan);
                stmt.setString(2, idMobil);
                stmt.setString(3, totalBiaya);
                stmt.setString(4, idPenjualan);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Data berhasil diperbarui!");
                refreshTable();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Gagal memperbarui data: " + ex.getMessage());
            }
        }
    }

    // 5. Fungsi Delete
    private void deleteData() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            String idPenjualan = table.getValueAt(selectedRow, 0).toString();

            try {
                String sql = "DELETE FROM data_penjualan WHERE idpenjualan = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, idPenjualan);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Data berhasil dihapus!");
                refreshTable();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Gagal menghapus data: " + ex.getMessage());
            }
        }
    }

    // 6. Fungsi Refresh
    private void refreshTable() {
        tableModel.setRowCount(0); // Clear data
        try {
            String sql = "SELECT * FROM data_penjualan";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                tableModel.addRow(new Object[] {
                        rs.getInt("idpenjualan"),
                        rs.getInt("idpelanggan"),
                        rs.getInt("idmobil"),
                        rs.getBigDecimal("totalbiaya")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal memuat data: " + ex.getMessage());
        }
    }

    // 7. Fungsi untuk menghitung total biaya berdasarkan harga mobil
    private void calculateTotalBiaya() {
        try {
            String idMobil = txtIdMobil.getText();
            String sql = "SELECT harga FROM data_mobil WHERE idmobil = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, idMobil);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                BigDecimal hargaMobil = rs.getBigDecimal("harga");
                BigDecimal totalBiaya = hargaMobil; // Bisa ditambahkan biaya tambahan jika perlu
                txtTotalBiaya.setText(totalBiaya.toString());
            } else {
                txtTotalBiaya.setText("Mobil tidak ditemukan");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal menghitung total biaya: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            CRUDDataPenjualan app = new CRUDDataPenjualan();
            app.setVisible(true);
        });
    }
}

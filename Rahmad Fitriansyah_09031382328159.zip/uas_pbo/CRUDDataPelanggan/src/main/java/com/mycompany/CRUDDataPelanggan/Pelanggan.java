package com.mycompany.CRUDDataPelanggan;
public class Pelanggan {
    private int idpelanggan;
    private String nama;
    private String nik;
    private String notelp;
    private String alamat;

    public Pelanggan(int idpelanggan, String nama, String nik, String notelp, String alamat) {
        this.idpelanggan = idpelanggan;
        this.nama = nama;
        this.nik = nik;
        this.notelp = notelp;
        this.alamat = alamat;
    }

    public int getIdpelanggan() {
        return idpelanggan;
    }

    public String getNama() {
        return nama;
    }

    public String getNik() {
        return nik;
    }

    public String getNotelp() {
        return notelp;
    }

    public String getAlamat() {
        return alamat;
    }
}

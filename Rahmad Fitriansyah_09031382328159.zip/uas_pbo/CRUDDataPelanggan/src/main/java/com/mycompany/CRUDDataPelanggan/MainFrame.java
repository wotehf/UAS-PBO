package com.mycompany.CRUDDataPelanggan;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class MainFrame extends JFrame {
    private JTextField nameField, nikField, notelpField, alamatField;
    private JTable table;
    private DefaultTableModel tableModel;
    private PelangganService pelangganService;

    public MainFrame() {
        pelangganService = new PelangganService();

        setTitle("CRUD Data Pelanggan");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel Input
        JPanel inputPanel = new JPanel();
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        inputPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5); // Padding antar komponen

        // Nama
        gbc.gridx = 0;
        gbc.gridy = 0;
        inputPanel.add(new JLabel("Nama:"), gbc);
        gbc.gridx = 1;
        nameField = new JTextField(20);
        inputPanel.add(nameField, gbc);

        // NIK
        gbc.gridx = 2;
        inputPanel.add(new JLabel("NIK:"), gbc);
        gbc.gridx = 3;
        nikField = new JTextField(20);
        inputPanel.add(nikField, gbc);

        // No Telepon
        gbc.gridx = 0;
        gbc.gridy = 1;
        inputPanel.add(new JLabel("No Telepon:"), gbc);
        gbc.gridx = 1;
        notelpField = new JTextField(20);
        inputPanel.add(notelpField, gbc);

        // Alamat
        gbc.gridx = 2;
        inputPanel.add(new JLabel("Alamat:"), gbc);
        gbc.gridx = 3;
        alamatField = new JTextField(20);
        inputPanel.add(alamatField, gbc);

        // Tombol CRUD
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        JButton createButton = new JButton("Create");
        createButton.addActionListener(this::handleCreate);
        JButton updateButton = new JButton("Update");
        updateButton.addActionListener(this::handleUpdate);
        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(this::handleDelete);
        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> refreshTable());

        buttonPanel.add(createButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);

        // Tabel
        tableModel = new DefaultTableModel(new String[]{"ID", "Nama", "NIK", "No Telepon", "Alamat"}, 0);
        table = new JTable(tableModel);
        table.setRowHeight(25);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS); // Menyesuaikan ukuran kolom secara otomatis
        JScrollPane tableScrollPane = new JScrollPane(table);

        // Layout Frame
        setLayout(new BorderLayout());
        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(tableScrollPane, BorderLayout.SOUTH);

        refreshTable(); // Load data awal
    }

    private void handleCreate(ActionEvent e) {
        pelangganService.createPelanggan(nameField.getText(), nikField.getText(), notelpField.getText(), alamatField.getText());
        refreshTable();
        clearFields();
    }

    private void handleUpdate(ActionEvent e) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            int id = (int) tableModel.getValueAt(selectedRow, 0);
            pelangganService.updatePelanggan(id, nameField.getText(), nikField.getText(), notelpField.getText(), alamatField.getText());
            refreshTable();
            clearFields();
        } else {
            JOptionPane.showMessageDialog(this, "Pilih baris untuk diupdate.");
        }
    }

    private void handleDelete(ActionEvent e) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            int id = (int) tableModel.getValueAt(selectedRow, 0);
            pelangganService.deletePelanggan(id);
            refreshTable();
        } else {
            JOptionPane.showMessageDialog(this, "Pilih baris untuk dihapus.");
        }
    }

    private void refreshTable() {
        List<Pelanggan> pelangganList = pelangganService.readPelanggan();
        tableModel.setRowCount(0);
        for (Pelanggan pelanggan : pelangganList) {
            tableModel.addRow(new Object[]{pelanggan.getIdpelanggan(), pelanggan.getNama(), pelanggan.getNik(), pelanggan.getNotelp(), pelanggan.getAlamat()});
        }
    }

    private void clearFields() {
        nameField.setText("");
        nikField.setText("");
        notelpField.setText("");
        alamatField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}

package com.mycompany.CRUDDataMobil;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.sql.*;

public class CRUDDataMobil extends JFrame {
    private Connection conn;
    private DefaultTableModel tableModel;
    private JTable table;
    private JTextField txtMerk, txtTahun, txtHarga;
    private JButton btnCreate, btnUpdate, btnDelete, btnRefresh;

    public CRUDDataMobil() {
        initUI();
        connectToDatabase();
        refreshTable();
    }

    // 1. Inisialisasi UI
    private void initUI() {
        setTitle("CRUD Data Mobil");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLayout(null);

        JLabel lblMerk = new JLabel("Merk:");
        JLabel lblTahun = new JLabel("Tahun:");
        JLabel lblHarga = new JLabel("Harga:");

        txtMerk = new JTextField();
        txtTahun = new JTextField();
        txtHarga = new JTextField();

        lblMerk.setBounds(20, 60, 80, 25);
        lblTahun.setBounds(20, 100, 80, 25);
        lblHarga.setBounds(20, 140, 80, 25);

        txtMerk.setBounds(100, 60, 200, 25);
        txtTahun.setBounds(100, 100, 200, 25);
        txtHarga.setBounds(100, 140, 200, 25);

        btnCreate = new JButton("Create");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnRefresh = new JButton("Refresh");

        btnCreate.setBounds(320, 20, 100, 25);
        btnUpdate.setBounds(320, 60, 100, 25);
        btnDelete.setBounds(320, 100, 100, 25);
        btnRefresh.setBounds(320, 140, 100, 25);

        // Tabel untuk menampilkan data mobil
        tableModel = new DefaultTableModel(new String[]{"ID Mobil", "Merk", "Tahun", "Harga"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 200, 750, 300);

        // Tambahkan komponen ke frame
        add(lblMerk);
        add(lblTahun);
        add(lblHarga);
        add(txtMerk);
        add(txtTahun);
        add(txtHarga);
        add(btnCreate);
        add(btnUpdate);
        add(btnDelete);
        add(btnRefresh);
        add(scrollPane);

        // Event Listener
        btnCreate.addActionListener(e -> createData());
        btnUpdate.addActionListener(e -> updateData());
        btnDelete.addActionListener(e -> deleteData());
        btnRefresh.addActionListener(e -> refreshTable());

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int selectedRow = table.getSelectedRow();
                txtMerk.setText(tableModel.getValueAt(selectedRow, 1).toString());
                txtTahun.setText(tableModel.getValueAt(selectedRow, 2).toString());
                txtHarga.setText(tableModel.getValueAt(selectedRow, 3).toString());
            }
        });
    }

    // 2. Koneksi ke Database
    private void connectToDatabase() {
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/showroom", "root", "");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database connection failed: " + ex.getMessage());
        }
    }

    // 3. Fungsi Create
    private void createData() {
        String merk = txtMerk.getText();
        String tahun = txtTahun.getText();
        String harga = txtHarga.getText();

        try {
            String sql = "INSERT INTO data_mobil (merk, tahun, harga) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, merk);
            stmt.setString(2, tahun);
            stmt.setString(3, harga);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan!");
            refreshTable();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal menambahkan data: " + ex.getMessage());
        }
    }

    // 4. Fungsi Update
    private void updateData() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            String idMobil = table.getValueAt(selectedRow, 0).toString();
            String merk = txtMerk.getText();
            String tahun = txtTahun.getText();
            String harga = txtHarga.getText();

            try {
                String sql = "UPDATE data_mobil SET merk = ?, tahun = ?, harga = ? WHERE idmobil = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, merk);
                stmt.setString(2, tahun);
                stmt.setString(3, harga);
                stmt.setString(4, idMobil);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Data berhasil diperbarui!");
                refreshTable();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Gagal memperbarui data: " + ex.getMessage());
            }
        }
    }

    // 5. Fungsi Delete
    private void deleteData() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            String idMobil = table.getValueAt(selectedRow, 0).toString();

            try {
                String sql = "DELETE FROM data_mobil WHERE idmobil = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, idMobil);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Data berhasil dihapus!");
                refreshTable();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Gagal menghapus data: " + ex.getMessage());
            }
        }
    }

    // 6. Fungsi Refresh
    private void refreshTable() {
        tableModel.setRowCount(0); // Clear data
        try {
            String sql = "SELECT * FROM data_mobil";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("idmobil"),
                        rs.getString("merk"),
                        rs.getString("tahun"),
                        rs.getBigDecimal("harga")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal memuat data: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            CRUDDataMobil app = new CRUDDataMobil();
            app.setVisible(true);
        });
    }
}